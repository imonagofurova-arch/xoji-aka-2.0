# casflux

GitHub Pages yoki har qanday hostingga biriktirib ishlatish uchun tayyor va ixcham HTML loyiha.

## Qanday ishlatiladi:
1. `index.html` faylini reponing asosiy papkasiga joylang.
2. GitHub-da **Settings** > **Pages** bo'limiga o'tib, branch-ni `main` qilib saqlang.
